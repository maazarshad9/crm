<?php $__env->startPush('css'); ?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.partials.header', ['title' => __('Add New Project')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-xl-12 order-xl-1">
            <div class="card bg-secondary shadow">
                <div class="card-header bg-white border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Projects Management')); ?></h3>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo e(route('projects.store')); ?>" autocomplete="off">
                        <?php echo csrf_field(); ?>

                        <h6 class="heading-small text-muted mb-4"><?php echo e(__('Project information')); ?></h6>
                        <div class="pl-lg-4">
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-name"><?php echo e(__('Project Name')); ?></label>
                                <input type="text" name="name" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="form-control-label" for="input-name"><?php echo e(__('Customer')); ?></label>
                                <select name="customer_id" class="form-control" data-toggle="select" title="Simple select" data-placeholder="Select user" required>
                                    <option value="" disabled>Select Customer</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>">
                                        <?php echo e(ucwords( $user->name )); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group<?php echo e($errors->has('total_price') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-name"><?php echo e(__('total_price')); ?></label>
                                <input type="number" name="total_price" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('total_price') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('total_price')); ?>" value="<?php echo e(old('total_price')); ?>" required autofocus>

                                <?php if($errors->has('total_price')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('total_price')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('booking_price') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-name"><?php echo e(__('booking_price')); ?></label>
                                <input type="number" name="booking_price" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('booking_price') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Cost')); ?>" value="<?php echo e(old('booking_price')); ?>" required autofocus>

                                <?php if($errors->has('booking_price')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('booking_price')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('confirmation_price') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-name"><?php echo e(__('confirmation_price')); ?></label>
                                <input type="number" name="confirmation_price" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('confirmation_price') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Cost')); ?>" value="<?php echo e(old('confirmation_price')); ?>" required autofocus>

                                <?php if($errors->has('confirmation_price')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('confirmation_price')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group<?php echo e($errors->has('allocation_price') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-name"><?php echo e(__('allocation_price')); ?></label>
                                <input type="number" name="allocation_price" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('allocation_price') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Cost')); ?>" value="<?php echo e(old('allocation_price')); ?>" required autofocus>

                                <?php if($errors->has('allocation_price')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('allocation_price')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-group input-group-alternative">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="ni ni-calendar-grid-58"></i></span>
                                            </div>
                                            <input name="last_date" class="form-control datepicker <?php echo e($errors->has('last_date') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Start Date')); ?>" placeholder="Select date" type="text" value="" required>
                                            <?php if($errors->has('last_date')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('last_date')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-group input-group-alternative">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="ni ni-calendar-grid-58"></i></span>
                                            </div>
                                            <input name="last_date" class="form-control datepicker <?php echo e($errors->has('last_date') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Last Date')); ?>" placeholder="Select date" type="text" value="" required>
                                            <?php if($errors->has('last_date')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('last_date')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <div class="text-center">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('argon')); ?>/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/js/select2.min.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('Projects Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/projects/relicsol/blackstone/resources/views/projects/create.blade.php ENDPATH**/ ?>