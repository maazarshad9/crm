properties
	-> name | house number
	-> address
	-> buying price
	-> selling price

Installments
	-> Plans
		-> create as many plans as one want (1 month, 2 months etc)
	-> index
		customer name
		installment plan
		paid installements
		missing installments
		paid amount
		pending amount

Sales
	-> one time sale
		-> property id
		-> customer id
		-> price
	-> installments
		-> property id
		-> customer id
		-> price
		-> installment plan id




Sales

on time sale
	property id
	customer id
	user id
	selling price

Installments
	property id
	customer id
	user id
	total_amount
	paid_amount
	pending_amount
	advance_payment
	monthly_payable
	payment_recurrence (1 month, 2 months)
	installment_plan (1 year, 2 year, 3 year)



















