<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.partials.header', [
    'title' => __('Project') . ' '. $project->name,
    'description' => __('This is project page. You can see the progress you\'ve made with your work and manage your projects or assigned tasks'),
    'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-4 order-xl-2 mb-5 mb-xl-0">
                <div class="card card-profile shadow">
                    <div class="card-header text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">
                            <div class="d-flex justify-content-center">
                                <h4>Project Statistics</h4>

                            </div>
                            <div class="d-flex justify-content-center">
                                        <h4>
                                            Customer: <?php echo e($project->customer->name); ?>

                                        </h4>
                                    </div>
                        </div>
                    <div class="card-body pt-0 pt-md-4">
                        
                        <div class="row">
                            <div class="col">
                                <div class="card-profile-stats d-flex justify-content-center mt-md-5">
                                    
                                    <div>
                                        <span class="heading"><?php echo e($project->total_price); ?></span>
                                        <span class="description"><?php echo e(__('Budget')); ?></span>
                                    </div>
                                    <div>
                                        <span class="heading"><?php echo e($totalComission); ?></span>
                                        <span class="description"><?php echo e(__('Total Commission')); ?></span>
                                    </div>
                                    <div>
                                        <span class="heading"><?php echo e($project->total_price - $totalComission); ?></span>
                                        <span class="description"><?php echo e(__('Profit')); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="col-12 mb-0"><?php echo e(__('Project Details')); ?></h3>
                        </div>
                        <div class="float-right">
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#agentModal">
                              Add new agent
                          </button>

                          <!-- Modal -->
                          <div class="modal fade" id="agentModal" tabindex="-1" role="dialog" aria-labelledby="agentModalLabel" aria-hidden="true">
                              <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="agentModalLabel">Modal title</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                  </button>
                              </div>
                              <div class="modal-body">
                                 <form method="post" action="<?php echo e(route('project.agent.store', $project)); ?>" autocomplete="off">
                                    <?php echo csrf_field(); ?>

                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Project information')); ?></h6>
                                    <div class="pl-lg-4">
                                       <div class="form-group">

                                        <label class="form-control-label" for="input-name"><?php echo e(__('Agent')); ?></label>
                                        <select name="member_id" class="form-control" data-toggle="select" title="Simple select" data-placeholder="Select Agent" required>
                                            <option value="" disabled>Select Agent</option>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id); ?>">
                                                <?php echo e(ucwords( $user->full_name )); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('booking_commission') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-name"><?php echo e(__('Booking commission')); ?></label>
                                        <input type="number" name="booking_commission" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('booking_commission') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Booking commission')); ?>" value="<?php echo e(old('booking_commission')); ?>" autofocus>

                                        <?php if($errors->has('booking_commission')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('booking_commission')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('allocation_commission') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-name"><?php echo e(__('Allocation commission')); ?></label>
                                        <input type="number" name="allocation_commission" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('allocation_commission') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Allocation commission')); ?>" value="<?php echo e(old('allocation_commission')); ?>" autofocus>

                                        <?php if($errors->has('allocation_commission')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('allocation_commission')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('confirmation_commission') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-name"><?php echo e(__('Confirmation commission')); ?></label>
                                        <input type="number" name="confirmation_commission" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('confirmation_commission') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Confirmation commission')); ?>" value="<?php echo e(old('confirmation_commission')); ?>" autofocus>

                                        <?php if($errors->has('confirmation_commission')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('confirmation_commission')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save changes</button>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body">
        <?php $__currentLoopData = $project->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row align-items-center">
            <div class="col-auto">
               <a href="#" class="avatar avatar-xl rounded-circle">
                <img src="<?php echo e(asset('argon')); ?>/img/theme/team-4-800x800.jpg" class="rounded-circle">
            </a>
        </div>
        <div class="col ml--2">
            <h4 class="mb-0">
                <a href="#!"><?php echo e($member->full_name); ?></a>
            </h4>
        </div>
        <div class="col-auto">
            <div class="table-responsive">
                <table class="table align-items-center">
                    <tbody>
                        <tr>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <div class="media-body">
                                        <span class="mb-0 text-sm">Booking Commission</span>
                                    </div>
                                </div>
                            </th>
                            <td>
                                <?php if($member->pivot->booking_commission): ?>
                                <button type="button" class="btn btn-sm btn-primary" title="Booking" disabled><?php echo e($member->pivot->booking_commission); ?></button> 
                                <?php else: ?>
                                <?php echo $__env->make('projects.partials.booking', [
                                    'project' => $project,
                                    'agent' => $member
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <div class="media align-items-center">
                                        <div class="media-body">
                                            <span class="mb-0 text-sm">Confirmation Commission</span>
                                        </div>
                                    </div>
                                </th>
                                <td>
                                    <?php if($member->pivot->confirmation_commission): ?>
                                    <button type="button" class="btn btn-sm btn-primary" title="Confirmation" disabled><?php echo e($member->pivot->confirmation_commission); ?></button> 
                                    <?php else: ?>
                                    <?php echo $__env->make('projects.partials.confirmation', [
                                        'project' => $project,
                                        'agent' => $member
                                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <div class="media align-items-center">
                                            <div class="media-body">
                                                <span class="mb-0 text-sm">Allocation Commission</span>
                                            </div>
                                        </div>
                                    </th>
                                    <td>
                                        <?php if($member->pivot->allocation_commission): ?>
                                        <button type="button" class="btn btn-sm btn-primary" title="Allocation" disabled><?php echo e($member->pivot->allocation_commission); ?></button> 
                                        <?php else: ?>
                                        <?php echo $__env->make('projects.partials.allocation', [
                                            'project' => $project,
                                            'agent' => $member
                                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Total Commission</th>
                                        <td><button type="button" class="btn btn-sm btn-primary" title="Booking" disabled><?php echo e($member->pivot->booking_commission + $member->pivot->confirmation_commission + $member->pivot->allocation_commission); ?></button> </td>
                                    </tr>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
                <br>
                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('User Profile')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/projects/relicsol/blackstone/resources/views/projects/show.blade.php ENDPATH**/ ?>