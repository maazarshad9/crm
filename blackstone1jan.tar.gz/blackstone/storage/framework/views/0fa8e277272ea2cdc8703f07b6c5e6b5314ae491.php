<div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-6">
        <div class="copyright text-center text-xl-left text-muted">
            &copy; <?php echo e(now()->year); ?> <a href="https://www.creative-tim.com" class="font-weight-bold ml-1" target="_blank">Relic Sol</a> &amp;
            <a href="https://www.updivision.com" class="font-weight-bold ml-1" target="_blank">Updivision</a>
        </div>
    </div>
    <div class="col-xl-6">
        <ul class="nav nav-footer justify-content-center justify-content-xl-end">
            <li class="nav-item">
                <a href="https://www.creative-tim.com" class="nav-link" target="_blank">CRM</a>
            </li>
        </ul>
    </div>
</div><?php /**PATH /var/www/projects/relicsol/blackstone/resources/views/layouts/footers/nav.blade.php ENDPATH**/ ?>