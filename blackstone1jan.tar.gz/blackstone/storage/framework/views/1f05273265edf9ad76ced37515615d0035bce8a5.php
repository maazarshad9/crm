<button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#allocationModal">
  Add Allocation
</button>

<div class="modal fade" id="allocationModal" tabindex="-1" role="dialog" aria-labelledby="allocationModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="allocationModalLabel">Allocation Commission</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form method="post" action="<?php echo e(route('project.commission', [$project, $member->id])); ?>" autocomplete="off">

        <?php echo csrf_field(); ?>
        <div class="modal-body">
          <div class="form-group<?php echo e($errors->has('allocation_commission') ? ' has-danger' : ''); ?>">
            <label class="form-control-label" for="input-name"><?php echo e(__('Allocation commission')); ?></label>
            <input type="number" name="allocation_commission" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('allocation_commission') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Allocation commission')); ?>" value="<?php echo e(old('allocation_commission')); ?>" autofocus>

            <?php if($errors->has('allocation_commission')): ?>
            <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('allocation_commission')); ?></strong>
            </span>
            <?php endif; ?>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
      </form>
    </div>
  </div>
</div><?php /**PATH /var/www/projects/relicsol/blackstone/resources/views/projects/partials/allocation.blade.php ENDPATH**/ ?>