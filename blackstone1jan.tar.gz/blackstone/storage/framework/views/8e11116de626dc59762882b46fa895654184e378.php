<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.partials.header', ['title' => __('Details')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

<div class="container-fluid mt--7">
	<div class="row">
		<div class="col-xl-4 order-xl-2 mb-5 mb-xl-0">
			<div class="card card-profile shadow">
				<div class="card-header text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">
					<div class="d-flex justify-content-center">
						<h4>Project Statistics</h4>

					</div>
				</div>
				<div class="card-body pt-0 pt-md-4">

					<div class="row">
						<div class="col">
							<div class="card-profile-stats d-flex justify-content-center mt-md-5">

								<div>
									<span class="heading"><?php echo e($user->projects->count()); ?></span>
									<span class="description"><?php echo e(__('Total Projects')); ?></span>
								</div>
								<div>
									<span class="heading">
										<?php echo e($user->getTotalCommission()); ?>

									</span>
									<span class="description"><?php echo e(__('Total Commission')); ?></span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="col-xl-8 order-xl-1">
			<div class="card bg-secondary shadow">
				<div class="card-header bg-white border-0">
					<h3>Projects & Total Commission</h3>
				</div>
				<div class="card-body">
					<?php $__currentLoopData = $user->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="row align-items-center">
						<div class="col-auto">
							<span>Project Customer :</span>
						</div>
						<div class="col ml--2">
							<h4 class="mb-0">
								<a href="#!"><?php echo e($project->customer->name); ?></a>
							</h4>
						</div>
					</div>
					<div class="col-auto">
						<div class="table-responsive">
							<table class="table align-items-center">
								<tbody>
									<tr>
										<th scope="row">
											<div class="media align-items-center">
												<div class="media-body">
													<span class="mb-0 text-sm">Booking Commission</span>
												</div>
											</div>
										</th>
										<td>
											<?php echo e($project->pivot->booking_commission); ?>

										</td>
									</tr>
									<tr>
										<th scope="row">
											<div class="media align-items-center">
												<div class="media-body">
													<span class="mb-0 text-sm">Confirmation Commission</span>
												</div>
											</div>
										</th>
										<td>
											<?php echo e($project->pivot->confirmation_commission); ?>

										</td>
									</tr>
									<tr>
										<th scope="row">
											<div class="media align-items-center">
												<div class="media-body">
													<span class="mb-0 text-sm">Allocation Commission</span>
												</div>
											</div>
										</th>
										<td>
											<?php echo e($project->pivot->allocation_commission); ?>

										</td>
									</tr>
									<tr>
										<th>Total Commission</th>
										<td> 
											<?php echo e($project->pivot->booking_commission + $project->pivot->confirmation_commission + $project->pivot->allocation_commission); ?>

										</td>
									</tr>
								</tbody>
							</table>

						</div>
					</div>
					<br>
					<hr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/projects/relicsol/blackstone/resources/views/users/show.blade.php ENDPATH**/ ?>